#!/usr/bin/env node
var fs = require('fs');
var path = require('path');
var distDir = path.join(__dirname, 'dist');
var nfDir = path.join(__dirname, 'node_modules');
var afDir = path.join(nfDir, '@fius');
try {
    var pkgs = fs.readdirSync(path.join(distDir, '@fius'));
    fs.mkdirSync(afDir, { recursive: true });
    for (var i = 0; i < pkgs.length; i++) {
        var pkg = pkgs[i];
        var target = path.join(distDir, '@fius', pkg);
        var link = path.join(afDir, pkg);
        try {
            if (!fs.existsSync(link)) {
                fs.symlinkSync(target, link, 'junction');
            }
        } catch(e) {}
    }
} catch(e) {}
